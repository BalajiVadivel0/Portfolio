const navbar = document.getElementById('navbar');
const navToggle = document.getElementById('navToggle');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.nav-link');

navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    navToggle.classList.toggle('active');
});

navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        navToggle.classList.remove('active');
    });
});

function updateActiveLink() {
    const sections = document.querySelectorAll('section[id]');
    const scrollY = window.pageYOffset;

    sections.forEach(section => {
        const sectionHeight = section.offsetHeight;
        const sectionTop = section.offsetTop - 100;
        const sectionId = section.getAttribute('id');
        const navLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);

        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            navLinks.forEach(link => link.classList.remove('active'));
            if (navLink) {
                navLink.classList.add('active');
            }
        }
    });
}

function handleNavbarScroll() {
    if (window.scrollY > 50) {
        navbar.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
    } else {
        navbar.style.boxShadow = '0 1px 2px 0 rgba(0, 0, 0, 0.05)';
    }
}

let scrollTimeout;
window.addEventListener('scroll', () => {
    if (scrollTimeout) return;
    
    scrollTimeout = setTimeout(() => {
        updateActiveLink();
        handleNavbarScroll();
        animateOnScroll();
        scrollTimeout = null;
    }, 16);
}, { passive: true });

let animationFrame;
function animateOnScroll() {
    if (animationFrame) return;
    
    animationFrame = requestAnimationFrame(() => {
        const elements = document.querySelectorAll('.animate-on-scroll:not(.animated)');
        const windowHeight = window.innerHeight;
        
        elements.forEach(element => {
            const rect = element.getBoundingClientRect();
            if (rect.top < windowHeight * 0.85 && rect.bottom > 0) {
                element.classList.add('animated');
            }
        });
        
        animationFrame = null;
    });
}

let skillAnimationFrame;
function animateSkillBars() {
    if (skillAnimationFrame) return;
    
    skillAnimationFrame = requestAnimationFrame(() => {
        const skillBars = document.querySelectorAll('.skill-progress:not(.animated)');
        const windowHeight = window.innerHeight;
        
        skillBars.forEach(bar => {
            const barTop = bar.getBoundingClientRect().top;
            
            if (barTop < windowHeight * 0.85) {
                const progress = bar.style.getPropertyValue('--progress');
                bar.style.width = progress;
                bar.classList.add('animated');
            }
        });
        
        skillAnimationFrame = null;
    });
}

document.querySelectorAll('.skill-progress').forEach(bar => {
    bar.style.width = '0';
});

window.addEventListener('scroll', animateSkillBars);

const contactForm = document.getElementById('contactForm');
const submitButton = document.getElementById('submitButton');
const formMessage = document.getElementById('formMessage');

contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    document.querySelectorAll('.error-message').forEach(error => {
        error.textContent = '';
    });
    formMessage.textContent = '';
    formMessage.className = 'form-message';
    
    const formData = {
        name: document.getElementById('name').value.trim(),
        email: document.getElementById('email').value.trim(),
        message: document.getElementById('message').value.trim()
    };
    
    let isValid = true;
    
    if (formData.name.length < 2) {
        document.getElementById('nameError').textContent = 'Name must be at least 2 characters';
        isValid = false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address';
        isValid = false;
    }
    
    if (formData.message.length < 10) {
        document.getElementById('messageError').textContent = 'Message must be at least 10 characters';
        isValid = false;
    }
    
    if (!isValid) {
        return;
    }
    
    submitButton.disabled = true;
    document.querySelector('.button-text').textContent = 'Sending...';
    document.querySelector('.button-loader').style.display = 'inline-block';
    
    try {
        const response = await fetch('http://localhost:5000/api/contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            formMessage.textContent = 'Message sent successfully! I\'ll get back to you soon.';
            formMessage.classList.add('success');
            contactForm.reset();
        } else {
            formMessage.textContent = data.message || 'Failed to send message. Please try again.';
            formMessage.classList.add('error');
        }
    } catch (error) {
        console.error('Error:', error);
        formMessage.textContent = 'Network error. Please check your connection and try again.';
        formMessage.classList.add('error');
    } finally {
        submitButton.disabled = false;
        document.querySelector('.button-text').textContent = 'Send Message';
        document.querySelector('.button-loader').style.display = 'none';
    }
});

document.addEventListener('DOMContentLoaded', () => {
    animateOnScroll();
    updateActiveLink();
    
    const typingText = document.getElementById('typingText');
    if (typingText) {
        const texts = [
            'Aspiring Software Developer',
            'Backend Specialist',
            'Full Stack Developer'
        ];
        let textIndex = 0;
        let charIndex = 0;
        let isDeleting = false;
        let typingSpeed = 100;
        
        function type() {
            const currentText = texts[textIndex];
            
            if (isDeleting) {
                typingText.textContent = currentText.substring(0, charIndex - 1);
                charIndex--;
                typingSpeed = 50;
            } else {
                typingText.textContent = currentText.substring(0, charIndex + 1);
                charIndex++;
                typingSpeed = 100;
            }
            
            if (!isDeleting && charIndex === currentText.length) {
                typingSpeed = 2000;
                isDeleting = true;
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
                typingSpeed = 500;
            }
            
            setTimeout(type, typingSpeed);
        }
        
        setTimeout(type, 1000);
    }
});

window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const shapes = document.querySelectorAll('.shape');
    
    shapes.forEach((shape, index) => {
        const speed = 0.5 + (index * 0.2);
        shape.style.transform = `translateY(${scrolled * speed}px)`;
    });
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        
        if (target) {
            const offsetTop = target.offsetTop - 70;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});
